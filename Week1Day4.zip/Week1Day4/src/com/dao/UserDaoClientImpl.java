package com.dao;

public class UserDaoClientImpl {

}
