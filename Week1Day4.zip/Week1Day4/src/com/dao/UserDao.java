package com.dao;

import java.util.Scanner;

import com.model.User;

public class UserDao {

	Scanner sc=new Scanner(System.in);
	
	public void add_task(int l,User []arr)
	{
		User u1=new User();
		
		System.out.println("Enter the Task Id:");
		
		u1.setTaskId(sc.nextInt());
		
		System.out.println("TaskTitle");
		
		System.out.println(" Enter the TaskTitle:");
		
		u1.setTaskTitle(sc.next());
		System.out.println(" Enter the TaskText:");
		
		u1.setTaskText(sc.next());
		
		System.out.println("Enter name to whom u want assign task");
		
		u1.setAssignedTask(sc.next());
		
		arr[l]=u1;
	
	}
}
