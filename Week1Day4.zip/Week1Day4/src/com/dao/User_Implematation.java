package Week1Day4;
import java.util.Scanner;

public class User_Implematation extends Main_Challenge{

	int TaskId;
	String TaskTitle ;
	String TaskText ;
	String assignedTask;
	
	
	public int getTaskId() {
		return TaskId;
	}


	public String getTaskTitle() {
		return TaskTitle;
	}


	public String getTaskText() {
		return TaskText;
	}


	public String getAssignedTask() {
		return assignedTask;
	}

	Scanner sc = new Scanner(System.in);
				
	public void add_task(int l , User_Implematation[] arr )  
	{		
		User_Implematation s = new User_Implematation();
		
			  System.out.println("Enter the task Id : ");
			     s.TaskId = sc.nextInt();
			       sc.nextLine();
			  
			  System.out.println("Enter the TaskTitle : ");
			     s.TaskTitle = sc.nextLine();
			  
			  System.out.println("Enter the TaskText : ");
			     s.TaskText = sc.nextLine();
			  
			  System.out.println("Enter the assignedTask : ");
			     s.assignedTask = sc.nextLine();
			     			     
			 arr[l] = s;
			     
	}


	public boolean update_task(int l , User_Implematation[] arr) 
	{
		 System.out.println("Enter the Task id to update : ");
		  int id = sc.nextInt() ;
		     sc.nextLine();
		
		     for(int i=0 ; i<l ; i++)
		     {		    	 
		    	 if(arr[i].TaskId == id)
		 		{	  
		    	  System.out.println("Enter the Task_id : ");
		 		     arr[i].TaskId = sc.nextInt();
		 		    sc.nextLine();
		 		     
		 		  System.out.println("Enter the TaskTitle : ");
		 		     arr[i].TaskTitle = sc.nextLine();
		 		  
		 		  System.out.println("Enter the TaskText : ");
		 		     arr[i].TaskText = sc.nextLine();
		 		  
		 		  System.out.println("Enter the assignedTask : ");
		 		     arr[i].assignedTask = sc.nextLine();
		 		     
		 		     return true ; 
		 		}		    		 		
		     }
		return false ;
		
	}


	public boolean delete_task(int l , User_Implematation[] arr) 
	{
		 System.out.println("Enter the Task id to delete : ");
		  int id = sc.nextInt() ;
		     sc.nextLine();
  	
		     for(int i=0 ; i<l ; i++)
		     {
		    	 if(arr[i].TaskId == id)
		 		{	  
		 		   	  arr[i] = arr[i+1];
		 		   	  
		 		   	  System.out.println("Successfully deleted..!");
		 		   	  
		 		   	  return true;
		 		 }   	 

		     }	     
			
		     return false ;
	}


	public void search_task(int l , User_Implematation[] arr) 
	{
		 System.out.println("Enter the Task id to search : ");
		  int id = sc.nextInt() ;
		     sc.nextLine();
		   
		     boolean flag = true ;
		 
		     for(int i=0 ; i<l ; i++)
		     {
		    	 if(arr[i].TaskId == id)
		 		{
		 			
		 			flag = true ;
		 			System.out.println("The Task is found ..!");
		 			break ;
		 		}
		    	 else
		    	 {
		    		 flag = false ;
		    	 }
		     }
		
		      if(!flag)
		      {
		    	  System.out.println("task is not found ..!");
		      }
		      	
	}



	public void display_task(int l , User_Implematation[] arr) 
	{		
		for(int i=0 ; i<l ; i++)
		{			
			System.out.println("Task "+ (i+1));
			System.out.println("Assigned to " + arr[i].assignedTask);
			System.out.println("Task_Id is " + arr[i].TaskId);
			System.out.println("TaskText is " + arr[i].TaskText);
			System.out.println("TaskTitle is " + arr[i].TaskTitle);
			System.out.println("----------------------------");
			System.out.println();
		}	
	}


	public void assigned_task(int l, User_Implematation[] arr)
	{
		 System.out.println("Enter the Task id to assigned : ");
		  int id = sc.nextInt() ;
		     sc.nextLine();
		     
		     User_Implematation s = new User_Implematation();
		     
		     boolean flag = true ;
		     
		     for(int i=0 ; i<l ; i++)
		     {
		    	 if(arr[i].TaskId == id)
		    	 {
		    		 s = arr[i] ;
		    		 System.out.println("Successfully Assigned..!");
		    		 flag =  true ;
		    		 break ;
		    	 }
		    	 else
		    	 {
		    		 flag = false ;
		    	 }
		     }
		
		      if(!flag)
		      {
		    	  System.out.println("Task id is not found ...!");
		      }
		
	}
	
	//------------------------------------
	
	
	public void task_crud_operation() 
	{
		System.out.println("-------CRUD OPERATION EXECUTION----------------");
		
         Scanner sc = new Scanner(System.in);	
		
		User_Implematation st = new User_Implematation();
		
		User_Implematation[] arr = new User_Implematation[100];
		
		boolean flag  = true ;
		int l= 0 ;
		
		do
		{
			System.out.println("1 . Add the task");
			System.out.println("2 . Update the task");
			System.out.println("3 . Delete the task");
			System.out.println("4 . Search the task");
			System.out.println("5 . Assigned the task");
			System.out.println("6 . Display the task");
			System.out.println("0 . Exit");
			
			System.out.println("Enter the your choice : ");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			   case 1 : 
			   {
				   if(l > arr.length)
				   {
					   System.out.println("OverFlow Condition");
				   }
				   else
				   {  					  
						 st.add_task(l , arr);
						   l++ ;
					   				   					   
				   }	
				   
				   break ;
			   }
			   
			   case 2 :
			   {		 
				  if(l == -1)    //to check empty or not ...
				  {
					  System.out.println("No value to update ");
				  }
				  else
				  {
					 st.update_task( l , arr);
					 
				  }
				  break ;
			   }
			   
			   case 3 : 
			   {		  
				   
				   if(l == -1)    //to check empty or not ...
					  {
						  System.out.println("No value to delete ");
					  }
					  else
					  {	 
						  st.delete_task(l,arr); 
						   l-- ;		  
					  }	
				   break ;
			   }
			   
			   case 4  :
			   {
				   if(l == -1)     //to check empty or not ...
					  {
						  System.out.println("No value to search ");
					  }
					  else
					  {
						  st.search_task(l,arr);
					  }
				   break ;
			   }
			   
			   case 5  :
			   {
				   if(l == -1)     //to check empty or not ...
					  {
						  System.out.println("No value to assigned ");
					  }
					  else
					  {
						  st.assigned_task(l,arr);
					  }
				   break ;
			   }
			   		   
			   case 6 : 
			   {
				     st.display_task( l , arr);
				     break ;
			   }
			   
			   
			   case 0 :
			   {
				   System.out.println("Task Program is EXIT Here...");
				   flag = false ;				   
				   break ;
			   }
			   
			   
			   default:
			   {
				   System.out.println("Wrong Choice... Choose Correct Option ...!");				   	
				   flag = true ;				    	  				  
				   break ; 
			   }
			   
				     
				
			}
		}
		while(flag);
		
	}


	public void visitor_display_task() 
	{
		Task_Implematation ts = new Task_Implematation();
		
		User_Implematation[] arr = new User_Implematation[100];
		
		ts.check_assigned_task(arr );
		
	}

	
	
	
	
	
	
	
	
  //----------------------
	
	
}
