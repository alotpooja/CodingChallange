package com.model;

public class User {
	private int TaskId;
	private String TaskTitle ;
	private String TaskText ;
	private String assignedTask;//assign task to visitor
	public int getTaskId() {
		return TaskId;
	}
	public void setTaskId(int taskId) {
		TaskId = taskId;
	}
	public String getTaskTitle() {
		return TaskTitle;
	}
	public void setTaskTitle(String taskTitle) {
		TaskTitle = taskTitle;
	}
	public String getTaskText() {
		return TaskText;
	}
	public void setTaskText(String taskText) {
		TaskText = taskText;
	}
	public String getAssignedTask() {
		return assignedTask;
	}
	public void setAssignedTask(String assignedTask) {
		this.assignedTask = assignedTask;
	}

}
